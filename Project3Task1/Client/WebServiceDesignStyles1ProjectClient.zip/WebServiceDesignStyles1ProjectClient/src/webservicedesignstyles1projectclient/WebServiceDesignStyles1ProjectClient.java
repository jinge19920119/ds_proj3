/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webservicedesignstyles1projectclient;

/**
 *
 * @author jinge
 */
public class WebServiceDesignStyles1ProjectClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        addSpy("Ge", "spy", "Pittsburgh", "jin");//add spy of myself
        System.out.println(getList());
        System.out.println(getListAsXML());
        addSpy("mikem", "spy", "Pittsburgh", "sesame");
        addSpy("joem", "spy", "North Hills", "xyz");
        addSpy("seanb", "spy commander", "South Hills", "abcdefg");
        addSpy("jamesb", "spy", "Adelaide", "sydney");
        addSpy("adekunle", "spy", "Pittsburgh", "secret");
        System.out.println(getList());
        System.out.println(getListAsXML());
        updateSpy("mikem", "super spy", "Pittsburgh", "sesame");
        System.out.println(getListAsXML());
        String result = getSpy("jamesb");
        System.out.println(result);
        deleteSpy("jamesb");
        result = getSpy("jamesb");
        System.out.println(result);
    }
    //methods that invoked from the service client
    private static String addSpy(java.lang.String name, java.lang.String title, java.lang.String location, java.lang.String password) {
        service.SpyService_Service service = new service.SpyService_Service();
        service.SpyService port = service.getSpyServicePort();
        return port.addSpy(name, title, location, password);
    }

    private static String deleteSpy(java.lang.String name) {
        service.SpyService_Service service = new service.SpyService_Service();
        service.SpyService port = service.getSpyServicePort();
        return port.deleteSpy(name);
    }

    private static String getList() {
        service.SpyService_Service service = new service.SpyService_Service();
        service.SpyService port = service.getSpyServicePort();
        return port.getList();
    }

    private static String getListAsXML() {
        service.SpyService_Service service = new service.SpyService_Service();
        service.SpyService port = service.getSpyServicePort();
        return port.getListAsXML();
    }

    private static String getSpy(java.lang.String name) {
        service.SpyService_Service service = new service.SpyService_Service();
        service.SpyService port = service.getSpyServicePort();
        return port.getSpy(name);
    }

    private static String updateSpy(java.lang.String name, java.lang.String title, java.lang.String location, java.lang.String password) {
        service.SpyService_Service service = new service.SpyService_Service();
        service.SpyService port = service.getSpyServicePort();
        return port.updateSpy(name, title, location, password);
    }
    
}
