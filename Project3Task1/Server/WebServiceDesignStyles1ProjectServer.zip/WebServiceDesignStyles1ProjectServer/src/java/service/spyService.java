/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import model.Spy;
import model.SpyList;

/**
 *
 * @author jinge
 */
@WebService(serviceName = "spyService")
public class spyService {
    static SpyList list= new SpyList();

    /**
     * Web service operation
     * Pre: A name, title, location, and password are provided as input.
     * Post: A new spy is added to the list of spies. The value returned
     * is a simple String representation of the spy.
     */
    @WebMethod(operationName = "addSpy")
    public String addSpy(@WebParam(name = "name") String name, @WebParam(name = "title") String title, @WebParam(name = "location") String location, @WebParam(name = "password") String password) {
        if(!list.containsSpy(name)){//check if it exists
            Spy newSpy= new Spy(name, title, location, password);//create a new spy and add into the list
            list.add(newSpy);
            return newSpy.toString();//return this spy as a string
        }else{
            return "no update has been made!";
        }
        
    }

    /**
     * Web service operation
     * Pre: A name, title, location, and password are provided as input.
     * Post: An existing spy is updated. The value returned
     * is a simple String representation of the updated spy.
     */
    @WebMethod(operationName = "updateSpy")
    public String updateSpy(@WebParam(name = "name") String name, @WebParam(name = "title") String title, @WebParam(name = "location") String location, @WebParam(name = "password") String password) {
        if(list.containsSpy(name)){
            Spy oldSpy= list.get(name);
            list.delete(oldSpy);//if exists, delete it and create a new user
            Spy newSpy= new Spy(name, title, location, password);
            list.add(newSpy);
            return newSpy.toString();
        }else {//if not exists, return the information
            return "no update was made!";
        }
        
    }

    /**
     * Web service operation
     * Pre: A name is provided as input.
     * Post: An existing spy is returned as a string. If no such spy exists then the message “No such spy” is returned.
     */
    @WebMethod(operationName = "getSpy")
    public String getSpy(@WebParam(name = "name") String name) {
        if(list.containsSpy(name)){
            return list.get(name).toString();//if exists, return the name
        } else {//if not, return the false information
            return "no such spy!";
        }
    }

    /**
     * Web service operation
     * Pre: A spy name is provided as input.
     * Post: The spy is deleted from the list of spies. The value returned is a simple String that says “Spy” <name> “was deleted from the list.”
     */
    @WebMethod(operationName = "deleteSpy")
    public String deleteSpy(@WebParam(name = "name") String name) {
        if(list.containsSpy(name)){//if exists, delete it from the list
            list.delete(list.get(name));
            return "Spy "+name+" was deleted from the list";
        }else {//if not, just return a string and show
            return "no such spy existed!";
        }
    }

    /**
     * Web service operation
     * Pre: None
     * Post: A simple string is returned that contains all of the spy data on the spy list. If the list is empty then an empty string is returned.
     */
    @WebMethod(operationName = "getList")
    public String getList() {
        return list.toString();//return the list as a string
    }

    /**
     * Web service operation
     * Pre: None
     * Post: An XML simple string is returned that contains all of the spy data on the list. 
     * If the list is empty then an empty XML string is returned. The XML string has a start and an end tag but no spies.
     */
    @WebMethod(operationName = "getListAsXML")
    public String getListAsXML() {
        return list.toXML();//return the list as a XML file
    }
}
