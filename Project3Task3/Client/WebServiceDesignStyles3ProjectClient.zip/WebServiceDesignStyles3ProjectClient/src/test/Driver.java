/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import model.Result;
import model.Spy;

/**
 *
 * @author jinge
 */
public class Driver {
    static public void main(String[] args){
        System.out.println("Begin main");
        Spy spy1 = new Spy("mikem", "spy", "Pittsburgh", "sesame");
        Spy spy2 = new Spy("joem", "spy", "Philadelphia", "obama");
        Spy spy3 = new Spy("seanb", "spy commander", "Adelaide", "pirates");
        Spy spy4 = new Spy("jamesb","007", "Boston","queen");
        System.out.println(doPut(spy1));//201
        System.out.println(doPut(spy2));//201
        System.out.println(doPut(spy3));//201
        System.out.println(doPut(spy4));//201
        System.out.println(doDelete("joem")); // 200 
        
        spy1.setPassword("Doris"); 
        System.out.println(doPost(spy1)); // 200
        System.out.println(doGetListAsXML()); // display xml 
        System.out.println(doGetListAsText()); // display text
        System.out.println(doGetSpyAsXML("mikem")); // display xml 
        System.out.println(doGetSpyAsText("joem")); // 404
        System.out.println(doGetSpyAsXML("mikem")); // display xml 
        System.out.println(doPut(spy2)); // 201 
        System.out.println(doGetSpyAsText("joem")); // display text 
        System.out.println("End main");
        
        
    }
    //get the spy in the form of string
    static public String doGetSpyAsText(String name){
        int status= 0;
        Result r= new Result();//use the Result object to get the result
        status= doGet(name, true, r);
        if(status==200)//if status is 200, prove it ok
            return r.getValue();
        return "404 Not Found";
        
    }
    //get the spy in the form of XML
    static public String doGetSpyAsXML(String name){
        int status= 0;
        Result r= new Result();
        status= doGet(name, false, r);
        if(status==200)
            return r.getValue();
        return "404 Not Found";
    }
    //get the list in the form of XML
    static public String doGetListAsXML(){
        Result r= new Result();
        doGet("", false, r);
        return r.getValue();
    }
    //get the list in the form of plain text
    static public String doGetListAsText(){
        Result r= new Result();
        doGet("", true, r);
        return r.getValue();
    }
    //update an existing spy
    static public int doPost(Spy spy){
        int status = 0;
        try {
            // Make call to a particular URL
            URL url = new URL("http://localhost:8080/WebServiceDesignStyles3ProjectServer/SpyListCollection/");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            // set request method to POST and send name value pair
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            // write to POST data area
            OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
            out.write(spy.toXMLforCall());
            out.close();
            // get HTTP response code sent by server
            status = conn.getResponseCode();
            //close the connection
            conn.disconnect();
        } // handle exceptions
        catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // return HTTP status
        return status;   
    }
    //get the spy or the list
    static public int doGet(String name, boolean ifText, Result r){
        // Make an HTTP GET passing the name on the URL line
         r.setValue("");
         String response = "";
         HttpURLConnection conn;
         int status = 0;
         try {
             // pass the name on the URL line
             URL url = new URL("http://localhost:8080/WebServiceDesignStyles3ProjectServer/SpyListCollection" + "//" + name);
             conn = (HttpURLConnection) url.openConnection();
             conn.setRequestMethod("GET");
             // tell the server what format we want back
             if(ifText)
                 conn.setRequestProperty("Accept", "text/plain");
             else 
                 conn.setRequestProperty("Accept", "text/xml");
             // wait for response
             status = conn.getResponseCode();
             // If things went poorly, don't try to read any response, just return.
             if (status != 200) {
                 return 404;
             }
             String output = "";
             // things went well so let's read the response
             BufferedReader br = new BufferedReader(new InputStreamReader(
                     (conn.getInputStream())));
             while ((output = br.readLine()) != null) {
                 response += output;
             }
             conn.disconnect();
         } catch (MalformedURLException e) {
             e.printStackTrace();
         } catch (IOException e) {
             e.printStackTrace();
         }

         // return value from server 
         // set the response object
         r.setValue(response);
         // return HTTP status to caller
         return status;
    }
    //create a new spy and add to the spyListCollection
    static public int doPut(Spy spy){
        int status = 0;
        
         try {  
		URL url = new URL("http://localhost:8080/WebServiceDesignStyles3ProjectServer/SpyListCollection/");
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("PUT");//set the header
		conn.setDoOutput(true);
                OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
                out.write(spy.toXMLforCall());//write to the stream
                out.close();
		status = conn.getResponseCode();
                conn.disconnect();
	     } 
             catch (MalformedURLException e) {
		   e.printStackTrace();
	     } catch (IOException e) {
		   e.printStackTrace();
	     }
        return status;
    }
    //delete a spy from the list
    static public int doDelete(String name){
        int status = 0;
         try {  
		URL url = new URL("http://localhost:8080/WebServiceDesignStyles3ProjectServer/SpyListCollection" + "//"+name);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("DELETE");//set the header
                status = conn.getResponseCode();
		conn.disconnect();  
	     } 
             catch (MalformedURLException e) {
		   e.printStackTrace();
	     } catch (IOException e) {
		   e.printStackTrace();
	     }
        return status;
    }
}
