/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Spy;
import model.SpyList;

/**
 *
 * @author jinge
 */
@WebServlet(name= "spyListCollection", urlPatterns= {"/SpyListCollection/*"})
public class SpyListCollection extends HttpServlet {

    static SpyList list= new SpyList();
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("Console: doGET visited");
        String result = "";
        String path= request.getPathInfo();
        boolean ifText= false;//set the flag of plain text or xml
        if(request.getHeader("Accept").equals("text/plain")){
            ifText= true;
        }
        if(path.equals("/")){//check whether a spy or a list
            if(ifText){
                response.setStatus(200);//set the header
                response.setContentType("text/plain;charset=UTF-8");
                String value= "";
                value= list.toString();
                PrintWriter out = response.getWriter();
                out.println(value);//write to the stream
                return;
            }
            else{
                response.setStatus(200);
                response.setContentType("text/xml;charset=UTF-8");
                String value= "";
                value= list.toXML();
                PrintWriter out = response.getWriter();
                out.println(value);
                return;
            }
        }
        String name = path.substring(1);//get the name of the spy
        if(list.containsSpy(name))
            response.setStatus(200);//set the status
        else 
            response.setStatus(404);
        if(ifText){//if plain text
            response.setContentType("text/plain;charset=UTF-8");
            String value = "";
            Spy spy= list.get(name);
            value= list.toString();
            PrintWriter out = response.getWriter();
            out.println(value);
            return;
        } else {//if XML text
            response.setContentType("text/xml;charset=UTF-8");
            Spy spy= list.get(name);
            String value = "";
            value= list.toXML();
            PrintWriter out = response.getWriter();
            out.println(value);
            return;
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("Console: doPost visited");
        // We are not using the accept header here.
        // Read what the client has placed in the POST data area
        BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream()));
        String data = br.readLine();//read from the buffer
        Spy newSpy= new Spy();
        newSpy.parseInput(data);//create a new Spy and parse to set the value
        if(!list.containsSpy(newSpy.getName())){
            // spy does not exist, return 404
            response.setStatus(404);
            return; 
        }
        Spy oldSpy= list.get(newSpy.getName());//get the spy, delete it and create a new one
        list.delete(oldSpy);
        list.add(newSpy);
        response.setStatus(200);
        return;
    }
    
    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
        System.out.println("Console: doPut visited");
        // Read what the client has placed in the PUT data area
        BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream()));
        String data = br.readLine();
        Spy newSpy= new Spy();
        newSpy.parseInput(data);
        if(list.containsSpy(newSpy.getName())){
            // spy alreay exists, return 405
            response.setStatus(405);
            return; 
        }
        list.add(newSpy);
        response.setStatus(201);
        return;
    }
    // Delete an existing spy from the list. If no such variable then return a 404
    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
        System.out.println("Console: doDelete visited");
        String result = "";
        // The name is on the path /name so skip over the '/'
        String name = (request.getPathInfo()).substring(1);
        if(!list.containsSpy(name)){
            //if this spy does not exist, return 404
            response.setStatus(404);
            return;
        }
        //if exists, get the object, delete it from the list and set the status to 200
        Spy spy= list.get(name);
        list.delete(spy);
        response.setStatus(200);
    }

    

}
