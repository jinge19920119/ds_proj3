/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.StringReader;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

/**
 *
 * @author jinge
 */
public class Spy {
    // instance data for spies 
    private String name=""; //name of the spy
    private String title=""; //title of the spy
    private String location=""; //location of the spy
    private String password=""; // password of the spy
    //getters and setters
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getLocation() {
        return location;
    }

    public String getName() {
        return name;
    }

    public String getTitle() {
        return title;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    //constructors of different input types
    public Spy(String name, String title, String location, String password) {
        this.name = name;
        this.title = title;
        this.location = location;
        this.password = password;
    }
    public Spy(String name, String title, String location) {
        this.name = name;
        this.title = title;
        this.location = location;
        this.password = "";
    }
    public Spy(String name) {
        this.name = name;
        this.title = "";
        this.location = "";
        this.password = "";
    }
    public Spy() {
        this.name = "";
        this.title = "";
        this.location = "";
        this.password = "";
    }
    //show the information of the spy in the form of XML
    public String toXML() {
        StringBuffer xml = new StringBuffer();
        xml.append("<spy>");
        xml.append("<name>" + name + "</name>");
        xml.append("<spyTitle>" + title + "</spyTitle>");
        xml.append("<location>" + location + "</location>");
        xml.append("<password>" + password + "</password>");
        xml.append("</spy>");
        return xml.toString();
    }
    //show the information of the spy in the form of XML
    public String toString(){
        return name+" "+title+" "+location+" "+password;
    }
    //parse the input and set the spy value
    public void parseInput(String input){
        Document spyDoc = this.getDocument(input);
        spyDoc.getDocumentElement().normalize();
        System.out.println("Root element :" + spyDoc.getDocumentElement().getNodeName());
        // the root element should be “spyMessage”
        NodeList nl = spyDoc.getElementsByTagName("name");
        Node n = nl.item(0);
        this.name = n.getTextContent();
        
        nl = spyDoc.getElementsByTagName("spyTitle");
        n = nl.item(0);
        this.title = n.getTextContent();
        
        nl = spyDoc.getElementsByTagName("location");
        n = nl.item(0);
        this.location = n.getTextContent();

        nl = spyDoc.getElementsByTagName("password");
        n = nl.item(0);
        this.password= n.getTextContent();
    }
    //helper method to get the document
    private Document getDocument(String xmlString) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        Document spyDoc = null;
        try {
            builder = factory.newDocumentBuilder();
            spyDoc = (Document) builder.parse(new InputSource(new StringReader(xmlString)));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return spyDoc;
    }
}
