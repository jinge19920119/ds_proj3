/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import model.Spy;
import model.SpyList;
import model.SpyMessage;
import java.util.*;

/**
 *
 * @author jinge
 */
@WebService(serviceName = "SpyService")
public class SpyService {
    static SpyList list= new SpyList();

    /**
     * There will always be an XML document within the string. 
     * The XML document describes what operation needs to be performed as well as information about a spy
     */
    @WebMethod(operationName = "spyOperation")
    public String spyOperation(@WebParam(name = "input") String input) {
        SpyMessage mess= new SpyMessage();//create a spyMessage
        mess.parseDocument(input);//parse the input string into it
        Spy spy= mess.getSpy();//create a new Spy object
        String operation= mess.getOperation();
        String result= new String();
        if(operation.contains("addSpy")){//check method and call different methods
            result= addSpy(spy);
        } else if(operation.contains("updateSpy")){
            result= updateSpy(spy);
        } else if(operation.contains("getSpyAsXML")){
            result= getSpyAsXML(spy);
        } else if(operation.contains("deleteSpy")){
            result= deleteSpy(spy);
        } else if(operation.equals("getList")){
            result= getList();
        } else if(operation.contains("getListAsXML")){
            result= getListAsXML();
        } else {
            result= "operation can not be detected!";
        }
        return result;
    }
     /**
     * Pre: XML as input string
     * Post: A new spy is added to the list of spies. The value returned
     * is a XML representation of the spy.
     */
    static private String addSpy(Spy spy){
        String name= spy.getName();
        if(!list.containsSpy(name)){//check if it exists
            list.add(spy);//add to the list
            return returnXML(spy);
        }else{
            return returnXML(null);
        }
    }
    /**
     * Pre: XML string as input.
     * Post: An existing spy is updated. The value returned
     * is a XML file representation of the updated spy.
     */
    static private String updateSpy(Spy spy){
        String name= spy.getName();
        if(list.containsSpy(name)){
            Spy oldSpy= list.get(name);
            list.delete(oldSpy);//if exists, delete it and create a new user
            list.add(spy);
            return returnXML(spy);
        }else {
            return returnXML(null);
        }
    }
    /**
     * Pre: XML string provided as input.
     * Post: XML file is returned
     */
    static private String getSpyAsXML(Spy spy){
        String name= spy.getName();
        if(list.containsSpy(name)){
            Spy newSpy= list.get(name);
            return returnXML(newSpy);//if it is in the list, return it. 
        } else {
            return returnXML(null);
        }
    }
    /**
     * Pre: XML string provided as input.
     * Post: this spy is deleted from the list. XML file is returned
     */
    static private String deleteSpy(Spy spy){
        String name= spy.getName();
        if(list.containsSpy(name)){//if exists, delete it from the list
            Spy newSpy= list.get(name);
            list.delete(spy);
            return returnXML(newSpy);
        }else {
            return returnXML(null);
        }
    }
    /**
     * Pre: XML string provided as input.
     * Post: get and return the List as a string
     */
    static private String getList(){
        String result= "";
        result+= "<spyMessage><result>operation success!</result><spyList>";
        result+= list.toString();
        result+= "</spyList></spyMessage>";//wrap the result and return it
        return result;
    }
    /**
     * Pre: XML string provided as input.
     * Post: get and return the List as a string
     */
    static private String getListAsXML(){
        String result= "";
        result+= "<spyMessage><result>operation success!</result>";
        result+= list.toXML();
        result+= "</spyMessage>";
        return result;//wrap the result and return it as a XML file
    }
    //helper method to convert the spy as a sreturn XML, to get the bonus point in task2
    static private String returnXML(Spy spy){
        StringBuilder result= new StringBuilder();
        result.append("<spyMessage>");
        if(spy!=null){
            result.append("<result>operation success!</result>");
            result.append("<spy>");
            result.append("<name>" + spy.getName() + "</name>");
            result.append("<spyTitle>" + spy.getTitle() + "</spyTitle>");
            result.append("<location>" + spy.getLocation() + "</location>");
            result.append("<password>" + spy.getPassword() + "</password>");
            result.append("</spy>");
        } else{
            result.append("<result>operation failed!</result>");
        }
        result.append("</spyMessage>");
        return result.toString();
    }
    
}
