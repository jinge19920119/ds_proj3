/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import model.Spy;
import model.SpyMessage;

/**
 *
 * @author jinge
 */
public class Driver {
    public static void main(String[] args){
        String result = "";
        System.out.println("Adding spy jamesb");
        Spy bond = new Spy("jamesb", "spy", "London", "james"); // create a spy
        SpyMessage sb = new SpyMessage(bond, "addSpy");// create a message
        result = spyOperation(sb.toXML());// make a call on the web service
        System.out.println(result);
        
        System.out.println("Adding spy seanb");
        Spy beggs = new Spy("seanb", "spy master", "Pittsburgh", "sean");// create a spy
        SpyMessage ss = new SpyMessage(beggs, "addSpy");// create a message
        result = spyOperation(ss.toXML());// make a call on the web service
        System.out.println(result);
        
        System.out.println("Adding spy joem");
        Spy mertz = new Spy("joem", "spy", "Los Angeles", "joe");// create a spy
        SpyMessage sj = new SpyMessage(mertz, "addSpy");// create a message
        result = spyOperation(sj.toXML());// make a call on the web service
        System.out.println(result);
        
        System.out.println("Adding spy mikem");
        Spy mccarthy = new Spy("mikem", "spy", "Ocean City Maryland", "sesame");// create a spy
        SpyMessage sm = new SpyMessage(mccarthy, "addSpy");// create a message
        result = spyOperation(sm.toXML());// make a call on the web service
        System.out.println(result);
        
        System.out.println("Displaying spy list");
        SpyMessage list = new SpyMessage(new Spy(), "getList");// create a message
        System.out.println(" "+list.toXML());
        result = spyOperation(list.toXML());// make a call on the web service
        System.out.println(result);
        
        System.out.println("Displaying spy list as XML");
        SpyMessage listXML = new SpyMessage(new Spy(), "getListAsXML");// create a message
        result = spyOperation(listXML.toXML());// make a call on the web service
        System.out.println(result);
        
        System.out.println("Updating spy jamesb");
        Spy newJames = new Spy("jamesb", "Cool Spy", "New Jersey", "sesame");// create a spy
        SpyMessage um = new SpyMessage(newJames, "updateSpy");// create a message
        result = spyOperation(um.toXML());// make a call on the web service
        System.out.println(result);
        
        System.out.println("Displaying spy list");
        list = new SpyMessage(new Spy(), "getList");// create a message
        result = spyOperation(list.toXML());// make a call on the web service
        System.out.println(result);
        
        System.out.println("Deleting spy jamesb");
        Spy james = new Spy("jamesb");
        SpyMessage dm = new SpyMessage(james, "deleteSpy");// create a message
        result = spyOperation(dm.toXML());// make a call on the web service
        System.out.println(result);
        
        System.out.println("Displaying spy list");
        list = new SpyMessage(new Spy(), "getList");// create a message
        result = spyOperation(list.toXML());// make a call on the web service
        System.out.println(result);
        
        System.out.println("Displaying spy list as XML");
        listXML = new SpyMessage(new Spy(), "getListAsXML");// create a message
        result = spyOperation(listXML.toXML());// make a call on the web service
        System.out.println(result);
        
        System.out.println("Deleting spy Amos");
        Spy amos = new Spy("amos");
        SpyMessage am = new SpyMessage(amos, "deleteSpy");// create a message
        result = spyOperation(am.toXML());// make a call on the web service
        System.out.println(result);

    }
    //methods invoked from the service
    private static String spyOperation(java.lang.String input) {
        service.SpyService_Service service = new service.SpyService_Service();
        service.SpyService port = service.getSpyServicePort();
        return port.spyOperation(input);
    }

    
}

