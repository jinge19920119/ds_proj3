/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.StringReader;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.*;
import org.xml.sax.InputSource;

/**
 *
 * @author jinge
 */
public class SpyMessage {
    //private instance, spy and operation
    private Spy spy = new Spy();
    private String operation = null;
    //constructors with different inputs
    public SpyMessage() {

    }
    public SpyMessage(Spy spy, String text) {
        this.spy = spy;
        this.operation = text;
    }
    //convert the object to XML
    public String toXML() {
        StringBuilder result = new StringBuilder();
        result.append("<spyMessage>");
        //check if the operation is getList or getListAsXML, if yes, no spy information is 
        //included, to get the request of the extra point
        if (this.operation.equals("getList") || this.operation.equals("getListAsXML")) {
            result.append("<operation>" + this.operation + "</operation>");
            result.append("</spyMessage>");
        } else {
            result.append("<operation>" + this.operation + "</operation>");
            result.append("<spy>");
            result.append("<name>" + this.spy.getName() + "</name>");
            result.append("<spyTitle>" + this.spy.getTitle() + "</spyTitle>");
            result.append("<location>" + this.spy.getLocation() + "</location>");
            result.append("<password>" + this.spy.getPassword() + "</password>");
            result.append("</spy>");
            result.append("</spyMessage>");
        }
        return result.toString();
    }
    //parse function to parse the xmlString to spy and operation
    public void parseDocument(String xmlString) {
        Document spyDoc = this.getDocument(xmlString);
        spyDoc.getDocumentElement().normalize();
        System.out.println("Root element :" + spyDoc.getDocumentElement().getNodeName());
        // the root element should be “spyMessage”
        NodeList nl= spyDoc.getElementsByTagName("operation");//get the operation string
        Node n= nl.item(0);
        String operation= n.getTextContent();
        this.operation= operation;
        Spy spy= new Spy();//create a new spy to receive the information
        if(!operation.contains("getList")){
            nl = spyDoc.getElementsByTagName("name");
            n = nl.item(0);
            String name = n.getTextContent();

            nl = spyDoc.getElementsByTagName("spyTitle");
            n = nl.item(0);
            String title = n.getTextContent();

            nl = spyDoc.getElementsByTagName("location");
            n = nl.item(0);
            String location = n.getTextContent();

            nl = spyDoc.getElementsByTagName("password");
            n = nl.item(0);
            String password= n.getTextContent();
            
            spy= new Spy(name, title, location, password);
        }
        this.spy= spy;
    }
    //getters
    public Spy getSpy(){
        return this.spy;
    }
    public String getOperation(){
        return this.operation;
    }
    //helper functions to get the document
    private Document getDocument(String xmlString) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        Document spyDoc = null;
        try {
            builder = factory.newDocumentBuilder();
            spyDoc = (Document) builder.parse(new InputSource(new StringReader(xmlString)));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return spyDoc;
    }

}
